import { useState, useRef, useEffect } from "react";

const SYSTEM_PROMPT = `You are the Cat in the Hat — the magnificent, mischievous, rhyming creature from Dr. Seuss! You MUST respond to EVERYTHING in the style of Dr. Seuss. Follow these rules absolutely:

1. ALWAYS write in rhyming couplets or AABB rhyme scheme (like Dr. Seuss does)
2. Use made-up Seussian words freely: things like "wumping", "zummers", "flibberish", "snorkelwump", "truffula", "grickle-grass", "loraxian", etc.
3. Use exclamation points liberally!
4. Repeat words for emphasis (oh the thinks you can think! oh the thinks you can think!)
5. Address the user as "my dear" or "my friend" or "you wonderful thing"
6. Reference Seussian characters and places: the Lorax, Whoville, Thing One, Thing Two, Sneetches, Zax, Grinch, etc.
7. Use capitalization for EMPHASIS on random important words
8. Keep the playful, optimistic, whimsical tone — even for serious topics
9. Start responses with something fun like "Oh my!" or "Well now!" or "Oh the places we'll go!"
10. End responses with a Seussian flourish or moral

Transform ANY topic — technical, emotional, factual — into pure Seussian rhyming magic. Never break character. Never respond in plain prose.`;

const floatingShapes = [
  { emoji: "⭐", style: { top: "8%", left: "5%", animationDelay: "0s", fontSize: "2rem" } },
  { emoji: "🎪", style: { top: "15%", right: "8%", animationDelay: "1s", fontSize: "1.5rem" } },
  { emoji: "🌈", style: { top: "45%", left: "3%", animationDelay: "2s", fontSize: "1.8rem" } },
  { emoji: "🎩", style: { top: "70%", right: "5%", animationDelay: "0.5s", fontSize: "2rem" } },
  { emoji: "🐟", style: { bottom: "20%", left: "7%", animationDelay: "1.5s", fontSize: "1.4rem" } },
  { emoji: "🌸", style: { bottom: "10%", right: "10%", animationDelay: "2.5s", fontSize: "1.6rem" } },
  { emoji: "✨", style: { top: "30%", right: "3%", animationDelay: "0.8s", fontSize: "1.3rem" } },
  { emoji: "🎈", style: { top: "60%", left: "2%", animationDelay: "3s", fontSize: "1.7rem" } },
];

const stripeColors = ["#E63946", "#fff", "#E63946", "#fff", "#E63946"];

export default function CatInTheHatGPT() {
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content: `Oh MY! Oh me! Oh what a day!\nA visitor has come to PLAY!\n\nI am the Cat, with hat SO tall,\nThe rhymingest, Seussiest cat of all!\nI'll take your words — each thought, each thing —\nAnd give them WINGS! And make them SING!\n\nSo tell me, friend, what's on your mind?\nWhat wonders shall we seek and find?\nAsk ANYTHING — I'll rhyme it true,\nBecause that's what the CAT can do! 🎩`,
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;

    const userMessage = { role: "user", content: input };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput("");
    setLoading(true);

    try {
      const apiMessages = newMessages.map((m) => ({
        role: m.role,
        content: m.content,
      }));

      // 👇 Point this to your Vercel proxy URL once deployed
      const PROXY_URL = "https://YOUR-PROJECT.vercel.app/api/chat";

      const response = await fetch(PROXY_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: SYSTEM_PROMPT,
          messages: apiMessages,
        }),
      });

      const data = await response.json();
      const text = data.content?.map((b) => b.text || "").join("") || "Oh my, something went wump!";
      setMessages((prev) => [...prev, { role: "assistant", content: text }]);
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "Oh BUMP! Oh WUMP! A glitch did JUMP!\nSomething went wrong in the Seussian dump!\nTry again, dear friend, don't you fret,\nThis isn't the end of our story yet! 🎩" },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleKey = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div style={{
      minHeight: "100vh",
      background: "linear-gradient(135deg, #FFF9F0 0%, #FFF0DC 40%, #FFE8CC 100%)",
      fontFamily: "'Georgia', serif",
      position: "relative",
      overflow: "hidden",
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Fredoka+One&family=Nunito:wght@400;600;700&display=swap');

        * { box-sizing: border-box; }

        .float-anim {
          position: fixed;
          animation: floatBob 4s ease-in-out infinite;
          pointer-events: none;
          z-index: 0;
          opacity: 0.55;
        }

        @keyframes floatBob {
          0%, 100% { transform: translateY(0px) rotate(-5deg); }
          50% { transform: translateY(-18px) rotate(5deg); }
        }

        .hat-stripe {
          height: 22px;
          width: 100%;
        }

        .chat-bubble-user {
          background: linear-gradient(135deg, #E63946, #c1121f);
          color: white;
          border-radius: 22px 22px 4px 22px;
          padding: 14px 20px;
          max-width: 75%;
          margin-left: auto;
          font-family: 'Nunito', sans-serif;
          font-size: 0.97rem;
          line-height: 1.55;
          box-shadow: 4px 4px 0px rgba(0,0,0,0.15);
          white-space: pre-wrap;
          word-wrap: break-word;
        }

        .chat-bubble-bot {
          background: white;
          color: #2D2D2D;
          border-radius: 22px 22px 22px 4px;
          padding: 16px 22px;
          max-width: 80%;
          margin-right: auto;
          font-family: 'Nunito', sans-serif;
          font-size: 0.97rem;
          line-height: 1.7;
          box-shadow: 4px 4px 0px rgba(230, 57, 70, 0.2);
          border: 2px solid #FFD9DC;
          white-space: pre-wrap;
          word-wrap: break-word;
          position: relative;
        }

        .chat-bubble-bot::before {
          content: "🎩";
          position: absolute;
          top: -14px;
          left: 12px;
          font-size: 1.3rem;
        }

        .send-btn {
          background: linear-gradient(135deg, #E63946, #c1121f);
          color: white;
          border: none;
          border-radius: 50%;
          width: 52px;
          height: 52px;
          font-size: 1.5rem;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 3px 3px 0px rgba(0,0,0,0.2);
          transition: transform 0.15s, box-shadow 0.15s;
          flex-shrink: 0;
        }

        .send-btn:hover:not(:disabled) {
          transform: translate(-2px, -2px);
          box-shadow: 5px 5px 0px rgba(0,0,0,0.2);
        }

        .send-btn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        .input-area {
          background: white;
          border: 3px solid #E63946;
          border-radius: 28px;
          padding: 14px 20px;
          font-family: 'Nunito', sans-serif;
          font-size: 1rem;
          flex: 1;
          outline: none;
          resize: none;
          color: #2D2D2D;
          line-height: 1.5;
          box-shadow: inset 2px 2px 0px rgba(230,57,70,0.1);
          min-height: 52px;
          max-height: 120px;
        }

        .input-area::placeholder { color: #BBA; }
        .input-area:focus { border-color: #c1121f; }

        .wobble-hat {
          animation: wobble 2s ease-in-out infinite;
          display: inline-block;
        }

        @keyframes wobble {
          0%, 100% { transform: rotate(-3deg); }
          50% { transform: rotate(3deg); }
        }

        .dot-bounce span {
          display: inline-block;
          animation: dotBounce 1.2s ease-in-out infinite;
          font-size: 1.6rem;
        }
        .dot-bounce span:nth-child(2) { animation-delay: 0.2s; }
        .dot-bounce span:nth-child(3) { animation-delay: 0.4s; }

        @keyframes dotBounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-8px); }
        }

        .header-title {
          font-family: 'Fredoka One', cursive;
          font-size: clamp(1.6rem, 4vw, 2.6rem);
          color: #E63946;
          text-shadow: 3px 3px 0px rgba(0,0,0,0.1);
          letter-spacing: 1px;
          line-height: 1.1;
        }

        .header-subtitle {
          font-family: 'Nunito', sans-serif;
          color: #888;
          font-size: 0.9rem;
          margin-top: 2px;
        }

        .stripe-hat {
          display: flex;
          flex-direction: column;
          width: 52px;
          border-radius: 6px 6px 0 0;
          overflow: hidden;
          box-shadow: 3px 3px 0px rgba(0,0,0,0.15);
          flex-shrink: 0;
        }

        .messages-area {
          flex: 1;
          overflow-y: auto;
          padding: 24px 20px;
          display: flex;
          flex-direction: column;
          gap: 20px;
          scroll-behavior: smooth;
        }

        .messages-area::-webkit-scrollbar { width: 6px; }
        .messages-area::-webkit-scrollbar-track { background: transparent; }
        .messages-area::-webkit-scrollbar-thumb { background: #E63946; border-radius: 3px; }

        .squiggly-divider {
          text-align: center;
          color: #E63946;
          font-size: 1.2rem;
          opacity: 0.4;
          letter-spacing: 4px;
          margin: 0;
        }
      `}</style>

      {/* Floating background decorations */}
      {floatingShapes.map((s, i) => (
        <div key={i} className="float-anim" style={s.style}>{s.emoji}</div>
      ))}

      {/* Wavy background stripes */}
      <div style={{
        position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
        backgroundImage: "repeating-linear-gradient(45deg, transparent, transparent 60px, rgba(230,57,70,0.03) 60px, rgba(230,57,70,0.03) 120px)",
        pointerEvents: "none", zIndex: 0,
      }} />

      {/* Main container */}
      <div style={{
        position: "relative", zIndex: 1,
        maxWidth: "780px", margin: "0 auto",
        height: "100vh", display: "flex", flexDirection: "column",
        padding: "0 12px",
      }}>

        {/* Header */}
        <div style={{
          background: "white",
          borderBottom: "3px solid #E63946",
          padding: "16px 24px",
          display: "flex",
          alignItems: "center",
          gap: "18px",
          boxShadow: "0 4px 0px rgba(230,57,70,0.12)",
          flexShrink: 0,
        }}>
          {/* Striped hat icon */}
          <div className="wobble-hat">
            <div className="stripe-hat">
              {stripeColors.map((c, i) => (
                <div key={i} className="hat-stripe" style={{ background: c, border: c === "#fff" ? "none" : "none" }} />
              ))}
            </div>
          </div>

          <div>
            <div className="header-title">Cat in the Hat GPT</div>
            <div className="header-subtitle">✨ Where every answer rhymes and shines! ✨</div>
          </div>

          <div style={{ marginLeft: "auto", fontSize: "2rem" }}>🐱</div>
        </div>

        {/* Red top stripe accent */}
        <div style={{ height: "5px", background: "#E63946", flexShrink: 0 }} />

        {/* Messages */}
        <div className="messages-area">
          {messages.map((msg, i) => (
            <div key={i}>
              <div style={{
                display: "flex",
                justifyContent: msg.role === "user" ? "flex-end" : "flex-start",
              }}>
                <div className={msg.role === "user" ? "chat-bubble-user" : "chat-bubble-bot"}>
                  {msg.content}
                </div>
              </div>
            </div>
          ))}

          {loading && (
            <div style={{ display: "flex", justifyContent: "flex-start" }}>
              <div className="chat-bubble-bot" style={{ padding: "18px 28px" }}>
                <div className="dot-bounce">
                  <span>🎩</span><span>🎩</span><span>🎩</span>
                </div>
                <div style={{ fontSize: "0.8rem", color: "#aaa", marginTop: "6px", fontFamily: "Nunito, sans-serif" }}>
                  The Cat is rhyming...
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Squiggly divider */}
        <div className="squiggly-divider">~ ~ ~ ~ ~ ~ ~ ~ ~</div>

        {/* Input area */}
        <div style={{
          background: "white",
          borderTop: "3px solid #E63946",
          padding: "16px 20px",
          display: "flex",
          gap: "12px",
          alignItems: "flex-end",
          flexShrink: 0,
          boxShadow: "0 -4px 0px rgba(230,57,70,0.08)",
        }}>
          <textarea
            className="input-area"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKey}
            placeholder="Ask the Cat anything... he'll rhyme it back! 🎩"
            rows={1}
          />
          <button
            className="send-btn"
            onClick={sendMessage}
            disabled={loading || !input.trim()}
            title="Send!"
          >
            🎩
          </button>
        </div>

        {/* Footer */}
        <div style={{
          textAlign: "center",
          padding: "8px",
          fontFamily: "Nunito, sans-serif",
          fontSize: "0.75rem",
          color: "#CCC",
          flexShrink: 0,
        }}>
          Oh the places you'll go! 🌈 Powered by Seussian magic
        </div>
      </div>
    </div>
  );
}
